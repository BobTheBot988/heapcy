import tempfile
import os
import shutil
import gzip
import heapcy


def string_getter(name: str, offset: int) -> str:
    with open(name, "+rb") as f:
        f.seek(offset)  # move to byte offset
        line_bytes: bytes = f.readline()  # read until b"\n"
        line: str = line_bytes.split(b" ", 1)[0].decode(
            "ascii", errors="replace"
        )  # -> str
    return line


def function():
    with tempfile.NamedTemporaryFile(delete=False) as tmpfile:
        with gzip.open("total_guesses.gz") as fopen:
            shutil.copyfileobj(fopen, tmpfile)
            temp_file_name = tmpfile.name

    with open(temp_file_name, "+rb") as f_open:
        my_heap = heapcy.Heap(100_000)

        while True:
            offset = f_open.tell()
            line = f_open.readline()

            if not line:
                break

            parts = line.rstrip(b"\b\n")
            parts = line.split(b" ", 1)
            if len(parts) != 2:
                continue

            prob = float(parts[1].decode(encoding="ascii"))
            heapcy.heappush(my_heap, prob, offset)

    lis = list()
    for tup in heapcy.nlargest(my_heap, 1000):
        lis.append(string_getter(temp_file_name, tup[1]))

    __import__("pprint").pprint(lis)
    os.remove(temp_file_name)


if __name__ == "__main__":
    function()
